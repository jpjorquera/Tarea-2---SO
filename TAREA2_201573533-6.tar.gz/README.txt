Se utiliza g++ como compilador.

Para correr compilar primero usando:
make

Luego ejecutar usando:
make run